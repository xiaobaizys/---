export interface CategoryType {
  objectId?: string;
  name: string;
  parentId: string;
  icon: string;
  children?: CategoryType[];
}
