export interface RoleType {
  objectId?: string;
  name: string;
  checkedKeys: string[];
}

export interface Account {
  username: string;
  password: string;
}

export interface UserInfoType {
  objectId?: string;
  roleId?: string;
  username: string;
  sessionToken?: string;
  logo: string;
  address: string;
  intro: string;
  lnglat?: [number, number];
  province?: string;
  city?: string;
  district?: string;
  checkedKeys: string[];
}

export interface JobType {
  jobName: string;
  salaryDesc: string;
  lv1: string;
  lv2: string;
  welfareList: Array;
  skills: Array;
  brandName: string;
  brandLogo: string;
  areaDistrict: string;
  cityName: string;
}

// 
export interface JobTypeDel {
  brandName: string;
 
}


