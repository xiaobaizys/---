// export const ID = 'DttvonYZfQ0R3n4hQYjJf8pp-gzGzoHsz'
// export const KEY = '6AVsuJLul6HO0830HBXTEx3k'
// export const DOMAIN = 'https://dttvonyz.lc-cn-n1-shared.com'

export const ID = 'WojHRvmpUDdDfo2kr9mfUVc2-gzGzoHsz'
export const KEY = 'RIiXkMSxvm1XzeptOeTOgvik'
export const DOMAIN = 'https://wojhrvmp.lc-cn-n1-shared.com'
