<template>
  <a-breadcrumb style="margin: 20px 0">
    <a-breadcrumb-item>首页</a-breadcrumb-item>
    <a-breadcrumb-item v-for="item in pathList">
      {{ routeMap[item] }}
    </a-breadcrumb-item>
  </a-breadcrumb>
</template>

<script setup lang="ts">
import { useRoute } from "vue-router";
import { watch, ref } from "vue";
import { routeMapTool } from "@/utils/tools";
const route = useRoute();
const routeMap = routeMapTool();
// console.log(routeMap);
const pathList = ref<string[]>([]);
const pathToArr = (path: string) => {
  // /category/list ==> ['/category','/category/list']
  let arr = path.split("/").filter((i) => i); // ['category','list']
  let pathArr = arr.map((_, index) => {
    return "/" + arr.slice(0, index + 1).join("/");
  });
  return pathArr; //['/category','/category/list']
};

watch(route, (newVal) => {
  console.log("路由变化了", newVal.path);
  pathList.value = pathToArr(newVal.path);
});
</script>

<style scoped></style>
