<template>
  <a-menu theme="dark" mode="inline" @click="handleMenu">
    <template v-for="item in menuList">
      <a-menu-item v-if="!item.children" :key="item.path">
        <component :is="item.meta!.icon" />
        <span>{{ item.meta!.label }}</span>
      </a-menu-item>
      <a-sub-menu v-else :key="item.path + '0'">
        <template #title>
          <span>
            <component :is="item.meta!.icon" />
            <span>{{ item.meta!.label }}</span>
          </span>
        </template>
        <!-- <div v-for="child in item.children" v-show="!child.meta.hidden"> -->
        <div v-for="child in item.children">
          <a-menu-item :key="child.path">
            {{ child.meta!.label }}
          </a-menu-item>
        </div>
      </a-sub-menu>
    </template>
  </a-menu>
</template>

<script setup lang="ts">
import { routes } from "@/router";
import { RouteRecordRaw, useRouter } from "vue-router";
import { cloneDeep } from "lodash-es";
import { useAccount } from "@/store/account";
import { onMounted, ref } from "vue";
const router = useRouter();
const handleMenu = ({ key }: { key: string }) => {
  router.push(key);
};
const account = useAccount();
const menuFn = (permission: string[]) => {
  let menu = cloneDeep(routes[0].children) as RouteRecordRaw[];
  function loop(arr: RouteRecordRaw[]) {
    for (let i = arr.length - 1; i >= 0; i--) {
      let bool = !permission.includes(arr[i].path); // /category
      if (bool) {
        // 在删除前查看permission中有没有相近的路径 ['/category/list']
        let findChild = permission.filter(
          (item) => item.indexOf(arr[i].path) != -1
        );
        if (!findChild.length) {
          arr.splice(i, 1);
          continue;
        }
      }
      if (arr[i].children) {
        loop(arr[i].children!);
      }
    }
  }
  loop(menu);
  return menu;
};
const menuList = ref<RouteRecordRaw[]>([]);
onMounted(() => {
  menuList.value = menuFn(account.userInfo!.checkedKeys);
});
</script>

<style scoped></style>
