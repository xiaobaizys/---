<template>
  <div class="demo-dropdown-wrap">
    <a-dropdown-button @click="handleButtonClick">
      {{ account.userInfo?.username }}
      <template #overlay>
        <a-menu @click="handleMenuClick">
          <a-menu-item key="1">
            <UserOutlined />
            个人设置
          </a-menu-item>
          <a-menu-item key="2">
            <UserOutlined />
            退出登录
          </a-menu-item>
        </a-menu>
      </template>
    </a-dropdown-button>
  </div>
</template>
<script lang="ts" setup>
import { UserOutlined } from '@ant-design/icons-vue'
import type { MenuProps } from 'ant-design-vue'
import { useAccount } from '@/store/account'
import { useRouter } from 'vue-router'
const router = useRouter()
const handleButtonClick = (e: Event) => {
  console.log('click left button', e)
}
const handleMenuClick: MenuProps['onClick'] = (e) => {
  console.log('click', e)
  if (e.key === '2') {
    account.userInfo = null
    router.push('/login')
  }
}

const account = useAccount()
</script>
<style lang="scss" scoped>
.demo-dropdown-wrap :deep(.ant-dropdown-button) {
  margin-right: 8px;
  margin-bottom: 8px;
}
</style>
