<template>
  <a-layout style="min-height: 100vh">
    <a-layout-sider v-model:collapsed="collapsed" collapsible>
      <div class="logo">芯招聘-后台</div>
      <SiderMenu />
    </a-layout-sider>
    <a-layout>
      <a-layout-header style="background: #fff; padding: 0">
        <a-row justify="end">
          <a-col>
            <AppDrop />
          </a-col>
        </a-row>
      </a-layout-header>
      <a-layout-content style="margin: 0 16px">
        <AppBreadcrumb />
        <div :style="{ padding: '24px', background: '#fff', minHeight: '360px' }">
          <!-- Bill is a cat. -->
          <RouterView />
        </div>
      </a-layout-content>
      <a-layout-footer style="text-align: center"> 芯招聘-后台 @Xin Recruitment - backend </a-layout-footer>
    </a-layout>
  </a-layout>
</template>
<script setup lang="ts">
import { ref } from 'vue'
import SiderMenu from './components/sider-menu.vue'
import AppBreadcrumb from './components/app-breadcrumb.vue'
import AppDrop from './components/app-drop.vue'
const collapsed = ref(false)
</script>
<style>
.logo {
  height: 32px;
  margin: 16px;
  background: rgba(255, 255, 255, 0.3);
  line-height: 32px;
  color: #fff;
  font-weight: bold;
  text-align: center;
  font-size: 20px;
}

.site-layout .site-layout-background {
  background: #fff;
}
[data-theme='dark'] .site-layout .site-layout-background {
  background: #141414;
}
</style>
