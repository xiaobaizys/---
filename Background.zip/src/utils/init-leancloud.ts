// SDK配置，让云端知晓提交图片者的ID、key
import Cloud from "leancloud-storage";
import { ID, KEY, DOMAIN } from "@/config";
Cloud.init({
  appId: ID,
  appKey: KEY,
  serverURL: DOMAIN,
});
