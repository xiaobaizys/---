export const testTool = () => {
  console.log(123);
};
