import axios from 'axios'
import { message } from 'ant-design-vue'

const instance = axios.create({
  baseURL: 'https://wojhrvmp.lc-cn-n1-shared.com/1.1/',
  headers: {
    'X-LC-Id': 'WojHRvmpUDdDfo2kr9mfUVc2-gzGzoHsz',
    'X-LC-Key': 'RIiXkMSxvm1XzeptOeTOgvik',
    'Content-Type': 'application/json',
  },

  // baseURL: 'https://dttvonyz.lc-cn-n1-shared.com/1.1/',
  // headers: {
  //   'X-LC-Id': 'DttvonYZfQ0R3n4hQYjJf8pp-gzGzoHsz',
  //   'X-LC-Key': '6AVsuJLul6HO0830HBXTEx3k',
  //   'Content-Type': 'application/json',
  // },
})

// 添加请求拦截器
instance.interceptors.request.use(
  function (config) {
    // 在发送请求之前做些什么
    return config
  },
  function (error) {
    // 对请求错误做些什么
    return Promise.reject(error)
  }
)

// 添加响应拦截器
instance.interceptors.response.use(
  function (response) {
    // 2xx 范围内的状态码都会触发该函数。
    // 对响应数据做点什么
    message.success('操作成功')
    return response
  },
  function (error) {
    // 超出 2xx 范围的状态码都会触发该函数。
    // 对响应错误做点什么
    message.error('操作失败')
    return Promise.reject(error)
  }
)

export default instance
