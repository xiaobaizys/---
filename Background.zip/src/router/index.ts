import { useAccount } from "@/store/account";
import { createRouter, createWebHashHistory } from "vue-router";
export const routes = [
  {
    path: "/",
    component: () => import("@/layout/index.vue"),
    children: [
      {
        path: "/",
        component: () => import("@/views/dashboard.vue"),
        meta: {
          label: "数据可视化",
          icon: "area-chart-outlined",
        },
      },
      {
        path: "/category",
        component: () => import("@/views/category/index.vue"),
        meta: {
          label: "分类管理",
          icon: "codepen-outlined",
        },
        children: [
          {
            path: "/category/list",
            component: () => import("@/views/category/list.vue"),
            meta: {
              label: "分类列表",
            },
          },
          {
            path: "/category/pub",
            component: () => import("@/views/category/pub.vue"),
            meta: {
              label: "发布分类",
            },
          },
          {
            path: "/category/edit",
            component: () => import("@/views/category/edit.vue"),
            meta: {
              label: "编辑分类",
              hidden: true,
            },
          },
        ],
      },
      {
        path: "/manager",
        redirect: "/manager/role",
        meta: {
          label: "系统设置",
          icon: "appstore-outlined",
        },
        children: [
          {
            path: "/manager/role",
            component: () => import("@/views/manager/role.vue"),
            meta: {
              label: "角色管理",
            },
          },
          {
            path: "/manager/user",
            component: () => import("@/views/manager/user.vue"),
            meta: {
              label: "账号管理",
            },
          },
        ],
      },
      {
        path: "/pinia",
        component: () => import("@/views/pinia-test/index.vue"),
        meta: {
          label: "Pinia状态机",
          icon: "radar-chart-outlined",
        },
      },
      {
        path: "/setting",
        component: () => import("@/views/setting.vue"),
        meta: {
          label: "企业设置",
          icon: "setting-outlined",
        },
      },
      {
        path: "/job",
        redirect: "/job/pub",
        meta: {
          label: "岗位管理",
          icon: "code-sandbox-outlined",
        },
        children: [
          {
            path: "/job/pub",
            component: () => import("@/views/job/pub.vue"),
            meta: {
              label: "岗位发布",
            },
          },
          {
            path: "/job/list",
            component: () => import("@/views/job/list.vue"),
            meta: {
              label: "岗位列表",
            },
          },
        ],
      },
      {
        path: "/permission",
        component: () => import("@/views/permission.vue"),
        meta: {
          label: "无权访问",
          icon: "setting-outlined",
          // hidden: true,
        },
      },
    ],
  },
  {
    path: "/login",
    component: () => import("@/views/login.vue"),
  },
];
const router = createRouter({
  history: createWebHashHistory(),
  routes,
});
router.beforeEach((to, from, next) => {
  console.log(to, from);
  if (!["/login", "/permission"].includes(to.path)) {
    const account = useAccount();
    if (account.userInfo) {
      let { checkedKeys } = account.userInfo;
      let whiteList = ["/404"].concat(checkedKeys); //路由白名单
      if (whiteList.includes(to.path)) {
        next();
      } else {
        next("/permission");
      }
      next();
    } else {
      next("/login");
    }
  } else {
    next(); //login 与 permission 直接放行
  }
});
export default router;
