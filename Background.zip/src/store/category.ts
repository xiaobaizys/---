import { categoryGet } from "@/api/pro";
import { CategoryType } from "@/types/pro";
import { defineStore } from "pinia";
interface CategoryStateType {
  list: CategoryType[];
}
export const useCategory = defineStore("category", {
  state: (): CategoryStateType => ({
    list: [],
  }),
  actions: {
    async initCategoryAction() {
      let res = await categoryGet();
      this.list = res.data.results;
    },
  },
  persist: {
    key: "fxjy-category",
  },
});
