import { defineStore } from "pinia";

export const useCounter = defineStore("count", {
  state: () => ({
    num: 100,
  }),
});
