import { roleGet, userLogin } from "@/api/user";
import { Account, UserInfoType } from "@/types/user";
import { defineStore } from "pinia";
import router from "@/router";
interface AccountStateType {
  userInfo: UserInfoType | null;
}
export const useAccount = defineStore("account", {
  state: (): AccountStateType => ({
    userInfo: null,
  }),
  actions: {
    async userLoginAction(account: Account) {
      let res = await userLogin(account);
      let role = await roleGet(res.data.roleId);
      this.userInfo = { ...res.data, ...role.data };
      router.push("/");
    },
  },
  persist: {
    key: "fxjy-userInfo",
  },
});
