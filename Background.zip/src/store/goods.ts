import { defineStore } from "pinia";
export const useGoods = defineStore("goods", {
  state: () => ({
    list: [
      { name: "商品名称1", price: 9999 },
      { name: "商品名称2", price: 9.999 },
      { name: "商品名称3", price: 99.99 },
    ],
  }),
  getters: {
    filterList(state) {
      return state.list.filter((item) => item.price > 600);
    },
  },
  persist: {
    key: "fxjy-goods",
  },
});
