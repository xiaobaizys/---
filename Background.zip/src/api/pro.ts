import { CategoryType } from '@/types/pro'
import request from '../utils/request'
import { JobType } from '@/types/user'

export const testPost = () => {
  return request.post('classes/Test', {
    name: '李四',
    score: 80,
  })
}
//分类发布
export const categoryPost = (category: CategoryType) => {
  return request.post('classes/category', category)
}

//分类请求
export const categoryGet = (all?: boolean) => {
  let where = all ? {} : { parentId: '0-0' }
  return request.get('classes/category', {
    params: {
      where,
    },
  })
}

//分类更新
export const categoryPut = (objectId: string, category: CategoryType) => {
  return request.put(`classes/category/${objectId}`, category)
}

//新增岗位
export const jobPost = (job: JobType) => {
  return request.post('classes/job', job)
}

// // 删除岗位
// export const jobDel = (jobDel: any) => {
//   console.log(jobDel);
//   return request.delete('classes/job',jobDel)
// }

// 删除岗位
export const jobDel = (jobDel: string) => {
  console.log(jobDel)
  return request.delete(`classes/job${jobDel}`)
}

//岗位列表
interface ConditionType {
  jobName: string | { $regex: any; $options: 'i' }
  lv1: string
}
export const jobGet = (condition: ConditionType = {} as ConditionType) => {
  let { jobName, lv1 } = condition
  let query: ConditionType = {} as ConditionType
  if (jobName) {
    // query.jobName = jobName; //普通约束查询
    query.jobName = { $regex: jobName, $options: 'i' } //模糊查询
  }
  if (lv1) {
    query.lv1 = lv1
  }
  let params = JSON.stringify(query)
  return request.get(`classes/job?where=${params}`)
}
