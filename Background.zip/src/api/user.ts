import { Account, RoleType, UserInfoType } from '@/types/user'
import request from '@/utils/request'
//新增角色
export const rolePost = (roleObj: RoleType) => {
  return request.post('classes/role', roleObj)
}

//角色列表
export const roleGet = (roleId?: string) => {
  let query = roleId ? `/${roleId}` : ''
  return request.get(`classes/role${query}`)
}

//修改角色
export const rolePut = (roleId: string, roleObj: RoleType) => {
  return request.put(`classes/role/${roleId}`, roleObj)
}

//角色删除
export const roleDel = (roleId: string) => {
  return request.delete(`classes/role/${roleId}`)
}

// 分配账号（注册）
export const userReg = (account: Account) => {
  return request.post('users', account)
}

//账号列表
export const userGet = () => {
  return request.get('users')
}

//登录
export const userLogin = (account: Account) => {
  return request.post('login', account)
}



//更新账号信息
export const userUpdate = (userId: string, token: string, userObj: UserInfoType) => {
  return request.put(`users/${userId}`, userObj, {
    headers: {
      'X-LC-Session': token,
    },
  })
}
