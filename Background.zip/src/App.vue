<script setup lang="ts">
// import HelloWorld from "./components/HelloWorld.vue";
// import MainLayout from "./layout/index.vue";
</script>

<template>
  <!-- <MainLayout /> -->
  <RouterView />
</template>

<style scoped></style>
