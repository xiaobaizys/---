<template>
  <a-form :model="formState" name="basic" :label-col="{ span: 4 }" :wrapper-col="{ span: 16 }" autocomplete="off" @finish="onFinish" @finishFailed="onFinishFailed">
    <a-form-item label="企业名称" name="username" :rules="[{ required: true, message: '请输入企业名称!' }]">
      <a-input v-model:value="formState.username" readonly />
    </a-form-item>

    <a-form-item label="企业LOGO" name="logo" :rules="[{ required: true, message: '请上传LOGO!' }]">
      <img-upload v-model="formState.logo" />
    </a-form-item>
    <a-form-item label="公司位置" name="address" :rules="[{ required: true, message: '请选择地址!' }]">
      <a-input v-model:value="formState.address" readonly placeholder="点击进行地图选址" @click="open = true" />
    </a-form-item>
    <a-form-item label="企业简介" name="intro" :rules="[{ required: true, message: '请填写简介' }]">
      <div class="rich-editor">
        <QuillEditor v-model:content="formState.intro" content-type="html" />
      </div>
    </a-form-item>

    <a-form-item :wrapper-col="{ offset: 8, span: 16 }">
      <a-button type="primary" html-type="submit">确定提交</a-button>
    </a-form-item>
  </a-form>
  <a-drawer v-model:open="open" title="地图选址" placement="bottom" height="700">
    <GodMap v-model="godInfo" />
    <template #extra>
      <a-space>
        {{ godInfo.address }}
        <a-button type="primary" @click="handleDone">确定</a-button>
      </a-space>
    </template>
  </a-drawer>
</template>
<script lang="ts" setup>
import { useAccount } from '@/store/account'
import { ref } from 'vue'
import { UserInfoType } from '@/types/user'
import GodMap from '@/components/god-map.vue'
import { QuillEditor } from '@vueup/vue-quill'
import '@vueup/vue-quill/dist/vue-quill.snow.css'
import { userUpdate } from '@/api/user'
const account = useAccount()
const formState = ref<UserInfoType>({
  username: '',
  logo: '',
  address: '1111',
  intro: '2',
})
const onFinish = (values: any) => {
  // console.log("Success:", values);
  let setting = {
    ...values,
    ...godInfo.value,
  }
  // console.log(setting);
  let { objectId, sessionToken } = account.userInfo!
  userUpdate(objectId as string, sessionToken as string, setting)
}

const onFinishFailed = (errorInfo: any) => {
  console.log('Failed:', errorInfo)
}

// 初始化渲染

formState.value = { ...account.userInfo! }

//a-drawer
const open = ref(false)
const godInfo = ref({
  address: '',
  province: '',
  city: '',
  district: '',
})
const handleDone = () => {
  open.value = false
  formState.value.address = godInfo.value.address
  // formState.value = {
  //   ...formState.value,
  //   ...godInfo.value,
  // };
}
</script>
<style scoped>
.rich-editor {
  height: 200px;
  margin-bottom: 50px;
}
</style>
