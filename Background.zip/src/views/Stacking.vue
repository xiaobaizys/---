<template>
  <e-charts class="chart" :option="option"></e-charts>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'

const data = ref([
  { value: 50, name: '开发' },
  { value: 60, name: '测试' },
  { value: 20, name: '数据' },
  { value: 10, name: '运营' },
  { value: 50, name: '设计' },
])

setInterval(() => {
  data.value = data.value.map((item) => ({
    ...item,
    value: Math.random() * 100,
  }))
}, 1000)

const option = computed(() => {
  return {
    title: {
      text: '芯招聘-堆叠面积图',
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985',
        },
      },
    },
    legend: {
      data: ['开发', '测试', '数据', '运营', '设计', '行政', '运维'],
    },
    toolbox: {
      feature: {
        saveAsImage: {},
      },
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true,
    },
    xAxis: [
      {
        type: 'category',
        boundaryGap: false,
        data: data.value.map((d) => d.name),
      },
    ],
    yAxis: [
      {
        type: 'value',
      },
    ],
    series: [
      {
        name: '开发',
        type: 'line',
        stack: 'Total',
        areaStyle: {},
        emphasis: {
          focus: 'series',
        },
        data: [45, 86, 125, 245, 365, 459, 478],
      },
      {
        name: '测试',
        type: 'line',
        stack: 'Total',
        areaStyle: {},
        emphasis: {
          focus: 'series',
        },
        data: [220, 182, 191, 234, 290, 330, 310],
      },
      {
        name: '数据',
        type: 'line',
        stack: 'Total',
        areaStyle: {},
        emphasis: {
          focus: 'series',
        },
        data: [150, 232, 201, 154, 190, 330, 410],
      },
      {
        name: '运营',
        type: 'line',
        stack: 'Total',
        areaStyle: {},
        emphasis: {
          focus: 'series',
        },
        data: [320, 332, 301, 334, 390, 330, 320],
      },
      {
        name: '设计',
        type: 'line',
        stack: 'Total',
        label: {
          show: true,
          position: 'top',
        },
        areaStyle: {},
        emphasis: {
          focus: 'series',
        },
        data: [245, 278, 311, 356, 378, 455, 489],
      },
      {
        name: '行政',
        type: 'line',
        stack: 'Total',
        label: {
          show: true,
          position: 'top',
        },
        areaStyle: {},
        emphasis: {
          focus: 'series',
        },
        data: [152, 256, 365, 459, 598, 678, 758],
      },
      {
        name: '运维',
        type: 'line',
        stack: 'Total',
        label: {
          show: true,
          position: 'top',
        },
        areaStyle: {},
        emphasis: {
          focus: 'series',
        },
        data: [456, 478, 536, 555, 578, 698, 785],
      },
    ],
  }
})
</script>

<style>
.chart {
  height: 400px;
}
</style>
