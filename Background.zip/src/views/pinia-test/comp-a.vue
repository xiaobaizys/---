<template>
  <div class="box">
    <h1>A组件,{{ count.num }}</h1>
    <a-button type="primary" @click="handleNum">数字+</a-button>
    <div v-for="(item, index) in goods.list" :key="index">{{ item.name }}---价格:{{ item.price }}</div>
    <h2>分类列表</h2>
    <div v-for="item in category.list" :key="item.objectId">
      {{ item.name }}
    </div>
    <e-charts class="chart" :option="option"></e-charts>
  </div>
</template>

<script setup lang="ts">
import { useCategory } from '@/store/category'
import { useCounter } from '@/store/count'
import { useGoods } from '@/store/goods'

import { computed } from 'vue'

const count = useCounter()
const goods = useGoods()
const handleNum = () => {
  count.num++
}

const category = useCategory()
category.initCategoryAction()

const option = computed(() => ({
  xAxis: {
    type: 'category',
    data: ['开发', '测试', '设计', '运维', '运营', '行政', '数据'],
  },
  yAxis: {
    type: 'value',
  },
  series: [
    {
      data: [
        {
          value: 120,
          itemStyle: {
            color: '#9400D3',
          },
        },

        {
          value: 70,
          itemStyle: {
            color: '#4169E1',
          },
        },
        {
          value: 30,
          itemStyle: {
            color: '#FF8C00',
          },
        },
        {
          value: 200,
          itemStyle: {
            color: '#FFFF00',
          },
        },
        {
          value: 70,
          itemStyle: {
            color: '#FF7F50',
          },
        },
        {
          value: 150,
          itemStyle: {
            color: '#a90000',
          },
        },
        {
          value: 10,
          itemStyle: {
            color: '#00FA9A',
          },
        },
      ],
      type: 'bar',
    },
  ],
}))
</script>

<style scoped>
.box {
  height: 500px;
  width: 50%;
}
.chart {
  text-align: center;
  height: 400px;
  padding-bottom: 100px;
}
</style>
