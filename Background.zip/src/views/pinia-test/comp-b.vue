<template>
  <div class="box">
    <h1>B组件,{{ num }}</h1>
    <a-button type="primary" @click="handleAdd">新增商品</a-button>
    <div v-for="(item, index) in goods.filterList" :key="index">{{ item.name }}---价格:{{ item.price }}</div>
    <e-charts class="chart" :option="option"></e-charts>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { useCounter } from '@/store/count'
import { useGoods } from '@/store/goods'

const { num } = storeToRefs(useCounter())
const goods = useGoods()
const handleAdd = () => {
  goods.list.push({
    name: '新商品',
    price: Math.round(Math.random() * 600 + 400),
  })
}

const option = {
  title: {
    text: '平均薪资饼图',
    subtext: '',
    left: 'center',
  },
  tooltip: {
    trigger: 'item',
  },
  legend: {
    orient: 'vertical',
    left: 'left',
  },
  series: [
    {
      name: 'Access From',
      type: 'pie',
      radius: '50%',
      data: [
        { value: 1048, name: '5-10k' },
        { value: 735, name: '10-13k' },
        { value: 580, name: '14-20' },
        { value: 484, name: '20-40k' },
        { value: 300, name: '50-100k' },
      ],
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 0, 0, 0.5)',
        },
      },
    },
  ],
}
</script>

<style scoped>
.box {
  height: 500px;
  width: 50%;
}

.chart {
  margin-top: 120px;
  text-align: center;
  height: 400px;
  padding-bottom: 100px;
}
</style>
