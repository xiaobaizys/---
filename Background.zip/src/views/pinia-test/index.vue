<template>
  <div class="cont">
    <CompA />
    <CompB />
  </div>
</template>

<script setup lang="ts">
import CompA from "./comp-a.vue";
import CompB from "./comp-b.vue";
</script>

<style scoped>
.cont {
  display: flex;
}
</style>
