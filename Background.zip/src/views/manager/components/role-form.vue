<template>
  <a-form
    :model="formState"
    name="basic"
    :label-col="{ span: 8 }"
    :wrapper-col="{ span: 16 }"
    autocomplete="off"
    @finish="onFinish"
    @finishFailed="onFinishFailed"
  >
    <a-form-item
      label="角色名称"
      name="name"
      :rules="[{ required: true, message: '请输入角色名称' }]"
    >
      <a-input v-model:value="formState.name" />
    </a-form-item>

    <a-form-item
      label="角色权限"
      name="checkedKeys"
      :rules="[{ required: true, message: '请选择角色权限' }]"
    >
      <a-tree
        v-model:checkedKeys="formState.checkedKeys"
        checkable
        :fieldNames="{ key: 'path' }"
        :tree-data="routes[0].children"
      >
        <template #title="scope">
          {{ scope.meta.label }}
        </template>
      </a-tree>
    </a-form-item>

    <a-form-item :wrapper-col="{ offset: 8, span: 16 }">
      <a-button type="primary" html-type="submit">{{
        roleData ? "修改角色" : "新增角色"
      }}</a-button>
    </a-form-item>
  </a-form>
</template>
<script lang="ts" setup>
import { ref, watch } from "vue";
import { routes } from "@/router";
import { rolePost, rolePut } from "@/api/user";
import { RoleType } from "@/types/user";
interface FormState {
  name: string;
  checkedKeys: string[];
}

const formState = ref<FormState>({
  name: "",
  checkedKeys: [],
});
const onFinish = (values: any) => {
  console.log("Success:", values);
  if (props.roleData) {
    rolePut(props.roleData.objectId!, values);
  } else {
    rolePost(values);
  }
};

const onFinishFailed = (errorInfo: any) => {
  console.log("Failed:", errorInfo);
};

// 编辑&新增
interface PropsType {
  roleData: RoleType | null;
}
let props = defineProps<PropsType>();
console.log("props数据", props);
if (props.roleData) {
  // formState.value = { ...props.roleData };
  formState.value = props.roleData;
}
watch(props, () => {
  console.log("props数据", props);
  if (props.roleData) {
    formState.value = props.roleData;
  } else {
    formState.value = {
      name: "",
      checkedKeys: [],
    };
  }
});
</script>
