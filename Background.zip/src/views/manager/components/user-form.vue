<template>
  <a-form
    :model="formState"
    name="basic"
    :label-col="{ span: 8 }"
    :wrapper-col="{ span: 16 }"
    autocomplete="off"
    @finish="onFinish"
    @finishFailed="onFinishFailed"
  >
    <a-form-item
      label="账号名称"
      name="username"
      :rules="[{ required: true, message: '请输入账号' }]"
    >
      <a-input v-model:value="formState.username" />
    </a-form-item>
    <a-form-item
      label="默认密码"
      name="password"
      :rules="[{ required: true, message: '请输入密码' }]"
    >
      <a-input v-model:value="formState.password" type="password" />
    </a-form-item>

    <a-form-item
      label="角色权限"
      name="roleId"
      :rules="[{ required: true, message: '请选择角色权限' }]"
    >
      <a-select
        ref="select"
        v-model:value="formState.roleId"
        :fieldNames="{ label: 'name', value: 'objectId' }"
        :options="roleList"
      ></a-select>
    </a-form-item>

    <a-form-item :wrapper-col="{ offset: 8, span: 16 }">
      <a-button type="primary" html-type="submit">新增账号</a-button>
    </a-form-item>
  </a-form>
</template>
<script lang="ts" setup>
import { roleGet, userReg } from "@/api/user";
import { RoleType } from "@/types/user";
import { ref } from "vue";
interface FormState {
  username: string;
  password: string;
  roleId: string;
}

const formState = ref<FormState>({
  username: "",
  password: "",
  roleId: "",
});
const onFinish = (values: any) => {
  console.log("Success:", values);
  userReg(values);
};

const onFinishFailed = (errorInfo: any) => {
  console.log("Failed:", errorInfo);
};

// 角色列表select
const roleList = ref<RoleType[]>([]);
roleGet().then((res) => {
  roleList.value = res.data.results;
});
</script>
