<template>
  <a-button type="primary" @click="handleDrawer(null)">新增角色</a-button>
  <a-table :columns="columns" :data-source="data">
    <template #bodyCell="{ column, record, index }">
      <template v-if="column.key === 'checkedKeys'">
        <a-tag color="blue" v-for="item in record.checkedKeys">{{ routeMap[item] }}</a-tag>
      </template>
      <template v-if="column.key === 'action'">
        <a-space>
          <a-button type="primary" size="small" @click="handleDrawer(record)">编辑</a-button>
          <a-popconfirm title="删除后无法找回哦?" ok-text="确认" cancel-text="取消" @confirm="handleDel(record.objectId, index)">
            <a-button type="primary" size="small" danger>删除</a-button>
          </a-popconfirm>
        </a-space>
      </template>
    </template>
  </a-table>
  <a-drawer v-model:open="open" class="custom-class" root-class-name="root-class-name" :title="editData ? '修改角色' : '新增角色'" placement="right">
    <RoleForm :role-data="editData" />
  </a-drawer>
</template>
<script lang="ts" setup>
import RoleForm from './components/role-form.vue'
import { ref } from 'vue'
import { RoleType } from '@/types/user'
import { roleGet, roleDel } from '@/api/user'
import { routeMapTool } from '@/utils/tools'
const routeMap = routeMapTool()
const columns = [
  {
    title: '角色名称',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: '角色权限',
    dataIndex: 'checkedKeys',
    key: 'checkedKeys',
  },
  {
    title: '操作',
    key: 'action',
  },
]

const open = ref<boolean>(false)
const data = ref<RoleType[]>([])
roleGet().then((res) => {
  data.value = res.data.results
})

// 编辑
const editData = ref<RoleType | null>(null)
const handleDrawer = (record: RoleType | null) => {
  open.value = true
  editData.value = record
}

// 删除
const handleDel = (roleId: string, idx: number) => {
  roleDel(roleId).then(() => {
    data.value.splice(idx, 1)
  })
}
</script>
