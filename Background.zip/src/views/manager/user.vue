<template>
  <a-button type="primary" @click="open = true">分配账号</a-button>
  <a-table :columns="columns" :data-source="data">
    <template #bodyCell="{ column }">
      <template v-if="column.key === 'action'">
        <a-space>
          <a-button type="primary" size="small">编辑</a-button>
          <a-popconfirm
            title="删除后无法找回哦?"
            ok-text="确认"
            cancel-text="取消"
            
          >
          <!-- @confirm="handleDel(record.objectId, index)" -->
            <a-button type="primary" size="small" danger >删除</a-button>
          </a-popconfirm>
        </a-space>
      </template>
    </template>
  </a-table>
  <a-drawer
    v-model:open="open"
    class="custom-class"
    root-class-name="root-class-name"
    title="新增账号"
    placement="right"
  >
    <UserForm />
  </a-drawer>
</template>
<script lang="ts" setup>
import UserForm from "./components/user-form.vue";
import { ref } from "vue";
import { RoleType } from "@/types/user";
import { userGet } from "@/api/user";
const columns = [
  {
    title: "账号名称",
    dataIndex: "username",
    key: "username",
  },
  {
    title: "角色名称",
    dataIndex: "roleId",
    key: "roleId",
  },
  {
    title: "操作",
    key: "action",
  },
];

const open = ref<boolean>(false);
const data = ref<RoleType[]>([]);
userGet().then((res) => {
  data.value = res.data.results;
});

// 删除
// const handleDel = (roleId: string, idx: number) => {
//   roleDel(roleId).then(() => {
//     data.value.splice(idx, 1)
//   })
// }


</script>
