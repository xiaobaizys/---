<template>
  <div>
    <h1>无权访问，请联系管理员</h1>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>
