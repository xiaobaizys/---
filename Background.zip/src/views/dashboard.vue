<template>
  <Stacking></Stacking>
  <e-charts class="chart" :option="option"></e-charts>
</template>

<script setup lang="ts">
import Stacking from './Stacking.vue'
import { ref, computed } from 'vue'

const data = ref([
  { value: 50, name: '开发' },
  { value: 60, name: '测试' },
  { value: 20, name: '数据' },
  { value: 10, name: '运营' },
  { value: 50, name: '设计' },
  { value: 50, name: '行政' },
  { value: 50, name: '运维' },
])

setInterval(() => {
  data.value = data.value.map((item) => ({
    ...item,
    value: Math.random() * 100,
  }))
}, 1000)

const option = computed(() => {
  return {
    title: {
      text: '芯招聘-折线图',
    },
    xAxis: {
      type: 'category',
      data: data.value.map((d) => d.name),
    },
    yAxis: {
      type: 'value',
    },
    series: [
      {
        data: data.value.map((d) => d.value),
        type: 'line',
      },
    ],
  }
})
</script>

<style scoped>
.chart {
  height: 400px;
  padding-bottom: 100px;
}
</style>
