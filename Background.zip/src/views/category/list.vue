<template>
  <a-table :columns="columns" :data-source="data" rowKey="objectId">
    <template #bodyCell="{ column, record }">
      <template v-if="column.key === 'icon'">
        <img :src="record.icon" class="icon" alt="" />
      </template>
      <template v-if="column.key === 'action'">
        <a-space>
          <a-button type="primary" size="small" @click="handleEdit(record)">编辑</a-button>
          <a-popconfirm title="删除后无法找回哦?" ok-text="确认" cancel-text="取消">
            <a-button type="primary" danger size="small">删除</a-button>
          </a-popconfirm>
        </a-space>
      </template>
    </template>
  </a-table>
</template>
<script lang="ts" setup>
import { categoryGet } from '@/api/pro'
import { CategoryType } from '@/types/pro'
import { categoryToTree } from '@/utils/tools'
import { ref } from 'vue'
import { useRouter } from 'vue-router'
const columns = [
  {
    title: '分类名称',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: '分类图标',
    dataIndex: 'icon',
    key: 'icon',
  },
  {
    title: '操作',
    key: 'action',
  },
]

const data = ref<Array<CategoryType>>([])
categoryGet(true).then((res) => {
  data.value = categoryToTree(res.data.results)
})

//编辑
const router = useRouter()
const handleEdit = (record: Omit<CategoryType, 'children'>) => {
  router.push({
    path: '/category/edit',
    query: record,
  })
}
</script>
<style scoped>
.icon {
  height: 50px;
}
</style>
