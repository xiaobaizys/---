<template>
  <a-row class="search" gutter="20" justify="between">
    <a-col :span="8">
      <a-input v-model:value="search.jobName" placeholder="输入岗位名称查询"></a-input>
    </a-col>
    <a-col :span="8">
      <a-select :options="cateList" :fieldNames="{ label: 'name', value: 'name' }" v-model:value="search.lv1" placeholder="选择岗位类型进行筛选" style="width: 100%" />
    </a-col>
    <a-col :span="6">
      <a-button type="primary" @click="handleSearch">查询</a-button>
    </a-col>
  </a-row>
  <a-table sticky :columns="columns" :data-source="data" :scroll="{ x: 1500 }">
    <template #bodyCell="{ column }">
      <template v-if="column.key === 'operation'">
        <a-space>
          <a-button type="primary" size="small">编辑</a-button>
          <a-popconfirm title="删除后无法找回哦?" ok-text="确认" cancel-text="取消">
            <a-button type="primary" danger size="small" >删除</a-button>
          </a-popconfirm>
        </a-space>
      </template>
    </template>
  </a-table>
</template>
<script lang="ts" setup>
import { categoryGet, jobGet } from '@/api/pro'
import { CategoryType } from '@/types/pro'
import type { TableColumnsType } from 'ant-design-vue'
import { reactive, ref } from 'vue'
const columns = ref<TableColumnsType>([
  {
    title: '岗位名称',
    dataIndex: 'jobName',
    key: 'jobName',
    fixed: 'left',
  },
  {
    title: '岗位薪资',
    dataIndex: 'salaryDesc',
    key: 'salaryDesc',
    fixed: 'left',
  },
  {
    title: '岗位分类',
    dataIndex: 'lv1',
    key: 'lv1',
  },
  {
    title: '城市',
    dataIndex: 'cityName',
    key: 'cityName',
  },
  {
    title: '地区',
    dataIndex: 'areaDistrict',
    key: 'areaDistrict',
  },
  {
    title: '公司规模',
    dataIndex: 'brandScaleName',
    key: 'brandScaleName',
  },
  {
    title: '所属行业',
    dataIndex: 'brandIndustry',
    key: 'brandIndustry',
  },
  {
    title: '操作',
    key: 'operation',
    fixed: 'right',
    width: 150,
  },
])

const data: any = ref([])
jobGet().then((res) => {
  data.value = res.data.results
})

//岗位类型
const cateList = ref<CategoryType[]>([])
categoryGet().then((res) => {
  cateList.value = res.data.results
})


// 查询
const search = reactive({
  jobName: '',
  lv1: '',
})
const handleSearch = () => {
  console.log(search)
  jobGet(search).then((res) => {
    data.value = res.data.results
  })
}
</script>
<style scoped>
#components-table-demo-summary tfoot th,
#components-table-demo-summary tfoot td {
  background: #fafafa;
}
[data-theme='dark'] #components-table-demo-summary tfoot th,
[data-theme='dark'] #components-table-demo-summary tfoot td {
  background: #1d1d1d;
}
.search {
  margin-bottom: 20px;
}
</style>
