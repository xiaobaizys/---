<template>
  <a-form :label-col="labelCol" :wrapper-col="wrapperCol">
    <a-form-item label="岗位名称" v-bind="validateInfos.jobName">
      <a-input v-model:value="modelRef.jobName" />
    </a-form-item>
    <a-form-item label="薪资待遇" v-bind="validateInfos.salaryDesc">
      <a-input v-model:value="modelRef.salaryDesc" />
    </a-form-item>
    <a-form-item label="归属类目" v-bind="validateInfos.category">
      <a-cascader v-model:value="modelRef.category" :options="parentList" :fieldNames="{ label: 'name', value: 'name' }" placeholder="请选择岗位类目" />
    </a-form-item>
    <a-form-item label="福利待遇" v-bind="validateInfos.welfareList">
      <a-tree-select v-model:value="modelRef.welfareList" show-search style="width: 100%" :dropdown-style="{ maxHeight: '400px', overflow: 'auto' }" placeholder="请选择福利待遇" allow-clear multiple tree-default-expand-all :tree-data="welfare" :fieldNames="{ label: 'value' }"> </a-tree-select>
    </a-form-item>
    <a-form-item label="技能要求" v-bind="validateInfos.skills">
      <a-textarea v-model:value="modelRef.skills" placeholder="请输入技能要求，技能之间用英文逗号隔开" :auto-size="{ minRows: 2, maxRows: 5 }" />
    </a-form-item>
    <a-form-item :wrapper-col="{ span: 14, offset: 4 }">
      <a-button type="primary" @click.prevent="onSubmit">创建</a-button>
      <a-button style="margin-left: 10px" @click="resetFields">重置</a-button>
    </a-form-item>
  </a-form>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { Form } from 'ant-design-vue'
import { categoryGet, jobPost } from '@/api/pro'
import { CategoryType } from '@/types/pro'
import { categoryToTree } from '@/utils/tools'
import { useAccount } from '@/store/account'

const account = useAccount()
const useForm = Form.useForm

const labelCol = { span: 4 }
const wrapperCol = { span: 18 }
const modelRef = reactive({
  jobName: '',
  salaryDesc: '',
  category: [],
  welfareList: [],
  skills: '',
})
const rulesRef = reactive({
  jobName: [
    {
      required: true,
      message: '请输入岗位名称',
    },
  ],
  salaryDesc: [
    {
      required: true,
      message: '请输入薪资待遇',
    },
  ],
  category: [
    {
      required: true,
      message: '请选择岗位类目',
    },
  ],
  welfareList: [
    {
      required: true,
      message: '请选择福利待遇',
    },
  ],
  skills: [
    {
      required: true,
      message: '请录入技能要求',
    },
  ],
})
const { resetFields, validate, validateInfos } = useForm(modelRef, rulesRef, {
  onValidate: (...args) => console.log(...args),
})
// 创建岗位
const onSubmit = () => {
  validate()
    .then(() => {
      let [lv1, lv2] = modelRef.category
      let { logo, username, city, district } = account.userInfo!
      let skills = modelRef.skills.split(',')
      let job = {
        ...modelRef,
        lv1,
        lv2: lv2 ? lv2 : '',
        brandLogo: logo,
        brandName: username,
        cityName: city as string,
        areaDistrict: district as string,
        skills,
      }
      console.log(job)
      jobPost(job)
    })
    .catch((err) => {
      console.log('error', err)
    })
}

// 初始化类目列表
const parentList = ref<Array<CategoryType>>([])
categoryGet(true).then((res) => {
  let tree = categoryToTree(res.data.results)
  console.log(tree)
  parentList.value = tree
})

//福利待遇
const welfare = [
  { value: '六险一金' },
  { value: '带薪休假1个月' },
  { value: '项目提成' },
  { value: '节日礼品' },
  { value: '16薪' },
  { value: '通勤接送' },
  { value: '每周旅游' },
  { value: '不加班' },
  { value: '包吃' },
  { value: '节假日加班费' },
  { value: '加班补助' },
  { value: '员工旅游' },
  { value: '股票期权' },
  { value: '节日福利' },
  { value: '法定节假日三薪' },
  { value: '带薪年假' },
  { value: '团建聚餐' },
  { value: '交通补助' },
  { value: '补充医疗保险' },
  { value: '定期体检' },
]
</script>
