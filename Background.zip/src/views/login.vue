<template>
  <a-row justify="center" align="middle" class="login-row">
    <a-col :span="10">
      <a-card>
        <template #title>
          <div class="logo">
            <img src="../assets/logo.png" alt="" />
            芯招聘-后台
          </div>
        </template>
        <a-form :model="formState" name="basic" :label-col="{ span: 6 }" :wrapper-col="{ span: 16 }" autocomplete="off" @finish="onFinish" @finishFailed="onFinishFailed">
          <a-form-item label="账号" name="username" :rules="[{ required: true, message: '请输入您的用户名！' }]">
            <a-input v-model:value="formState.username" />
          </a-form-item>

          <a-form-item label="密码" name="password" :rules="[{ required: true, message: '请输入您的密码！' }]">
            <a-input-password v-model:value="formState.password" />
          </a-form-item>

          <a-form-item name="remember" :wrapper-col="{ offset: 8, span: 8 }">
            <a-checkbox v-model:checked="formState.remember">记住密码</a-checkbox>
          </a-form-item>

          <a-form-item :wrapper-col="{ offset: 8, span: 8 }">
            <a-button type="primary" html-type="submit" block>登录</a-button>
          </a-form-item>
        </a-form>
      </a-card>
    </a-col>
  </a-row>
</template>
<script lang="ts" setup>
import { reactive } from 'vue'
import { useAccount } from '@/store/account'
const account = useAccount()
interface FormState {
  username: string
  password: string
  remember: boolean
}
const formState = reactive<FormState>({
  username: 'admins',
  password: '123',
  remember: true,
})
const onFinish = (values: any) => {
  console.log('Success:', values)
  account.userLoginAction(values)
}

const onFinishFailed = (errorInfo: any) => {
  console.log('Failed:', errorInfo)
}
</script>
<style lang="scss" scoped>
.login-row {
  /* background-color: #f0f0f0; */
  height: 100vh;
  // background-image: url('../assets/login-bg.jpg');

  background-image: url('https://img95.699pic.com/photo/40135/1351.gif_wh860.gif');
  background-size: cover;
}
.logo {
  font-size: 24px;
  font-weight: bold;
  text-align: center;
  padding: 40px;
  img {
    height: 50px;
    margin-right: 10px;
  }
  color: black;
}
</style>
