<!--
 * @Author: 千锋爱佛僧
 * @公众号: 大前端私房菜
 * @Slogan: 千锋精品教程，好学得不像实力派！
-->
<script setup lang="ts">
import { testTool } from "@/utils/test";
testTool();
</script>

<template></template>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>
