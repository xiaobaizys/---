<template>
  <div id="container"></div>
</template>

<script setup lang="ts">
import AMapLoader from '@amap/amap-jsapi-loader'
import { onMounted } from 'vue'
interface AddressInfo {
  address: string
  lnglat: [number, number]
  province: string
  city: string
  district: string
}
interface EmitsType {
  (e: 'update:modelValue', arg: AddressInfo): void
}
const emit = defineEmits<EmitsType>()
const initMap = () => {
  AMapLoader.load({
    // key: "ddaa7795f24c1dec822bc929c53fd5e0", // 申请好的Web端开发者Key，首次调用 load 时必填
    key: 'd35e13aebdb75c7a887ddd350159947d', // 申请好的Web端开发者Key，首次调用 load 时必填
    version: '2.0', // 指定要加载的 JSAPI 的版本，缺省时默认为 1.4.15
    plugins: ['AMap.Geocoder'], // 需要使用的的插件列表，如比例尺'AMap.Scale'等
  })
    .then((AMap) => {
      let map = new AMap.Map('container', {
        //设置地图容器id
        viewMode: '3D', //是否为3D地图模式
        zoom: 10, //初始化地图级别
        center: [113.612843, 23.522529], //初始化地图中心点位置
      })

      var geocoder = new AMap.Geocoder({
        city: '010', //城市设为北京，默认：“全国”
        radius: 1000, //范围，默认：500
      })
      var marker = new AMap.Marker()
      function regeoCode(lnglat: [number, number]) {
        map.add(marker)
        marker.setPosition(lnglat)
        geocoder.getAddress(lnglat, function (status: any, result: any) {
          if (status === 'complete' && result.regeocode) {
            var address = result.regeocode.formattedAddress
            let { province, city, district } = result.regeocode.addressComponent
            console.log(result)
            emit('update:modelValue', {
              address,
              province,
              city,
              district,
              lnglat,
            })
          } else {
            console.log('根据经纬度查询地址失败')
          }
        })
      }

      map.on('click', function (e: any) {
        console.log('经纬度信息', e)
        let { lng, lat } = e.lnglat
        regeoCode([lng, lat])
      })
      // document.getElementById("regeo").onclick = regeoCode;
      // document.getElementById('lnglat').onkeydown = function(e) {
      //     if (e.keyCode === 13) {
      //         regeoCode();
      //         return false;
      //     }
      //     return true;
      // };
    })
    .catch((e) => {
      console.log(e)
    })
}
onMounted(() => {
  initMap()
})
</script>

<style scoped>
#container {
  height: 600px;
  border: 1px solid red;
}
</style>
