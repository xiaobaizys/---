<template>
  <a-upload
    v-model:file-list="fileList"
    name="avatar"
    list-type="picture-card"
    class="avatar-uploader"
    :show-upload-list="false"
    :before-upload="beforeUpload"
    :customRequest="handleUpload"
  >
    <img
      v-if="imageUrl || modelValue"
      :src="imageUrl || modelValue"
      class="avatar"
      alt="avatar"
    />
    <div v-else>
      <loading-outlined v-if="loading"></loading-outlined>
      <plus-outlined v-else></plus-outlined>
      <div class="ant-upload-text">请选择图片</div>
    </div>
  </a-upload>
</template>
<script lang="ts" setup>
import { ref } from "vue";
import { PlusOutlined, LoadingOutlined } from "@ant-design/icons-vue";
import { message } from "ant-design-vue";
// import type { UploadChangeParam } from "ant-design-vue";
import { FileType } from "ant-design-vue/es/upload/interface";
import Cloud from "leancloud-storage";
interface PropsType {
  modelValue: string;
}
defineProps<PropsType>();

function getBase64(img: FileType, callback: (base64Url: string) => void) {
  const reader = new FileReader();
  reader.addEventListener("load", () => callback(reader.result as string));
  reader.readAsDataURL(img);
}

const fileList = ref([]);
const loading = ref<boolean>(false);
const imageUrl = ref<string>("");
interface EmitsType {
  (e: "update:modelValue", url: string): void;
}
const emits = defineEmits<EmitsType>();
const handleUpload = (info: any) => {
  // console.log(info);
  getBase64(info.file, async (base64) => {
    // console.log(base64);
    const file = new Cloud.File("fxjy.png", { base64 });
    let res: any = await file.save();
    // console.log(res);
    let { url } = res.attributes;
    imageUrl.value = url;
    emits("update:modelValue", url); //把数据提交给表单
  });
};

const beforeUpload = (file: any) => {
  const isJpgOrPng = file.type === "image/jpeg" || file.type === "image/png";
  if (!isJpgOrPng) {
    message.error("You can only upload JPG file!");
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error("Image must smaller than 2MB!");
  }
  return isJpgOrPng && isLt2M;
};
</script>
<style scoped>
.avatar-uploader > .ant-upload {
  width: 128px;
  height: 128px;
}
.ant-upload-select-picture-card i {
  font-size: 32px;
  color: #999;
}

.ant-upload-select-picture-card .ant-upload-text {
  margin-top: 8px;
  color: #666;
}
.avatar {
  width: 100%;
  height: 100%;
}
</style>
