<script>
	export default {
		onLaunch: function() {
			//定位
			uni.getLocation({
				success: (res) => {
					// console.log(res);
					let {longitude,latitude} = res
					// console.log(longitude,latitude);
					let url = `https://restapi.amap.com/v3/geocode/regeo?key=e0119d3cbd6eb284068484cadeb50e07&location=${longitude},${latitude}`
					uni.request({
						url,
						success: (res) => {
							console.log('地理位置',res);
							let {city,province} = res.data.regeocode.addressComponent
							let cityName = city.length ? city : province
							this.$store.commit('loc/initLocMut',{city:cityName,lnglat:[longitude,latitude]})
						}
					})
				}
			})
			//初始化用户信息
			try {
				const value = uni.getStorageSync('fxjy-userinfo-v3');
				if (value) {
					this.$store.commit('user/initInfoMut',value)
				}
			} catch (e) {
				// error
				console.log('没有提取到用户信息');
			}
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import url('colorui/main.css');
	@import url('colorui/icon.css');
	@import url('colorui/animation.css');
	@import './tuniao-ui/index.scss';
  @import './tuniao-ui/iconfont.css';
  @import url('./static/font/iconfont.css');
</style>
