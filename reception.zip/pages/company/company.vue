<template>
	<view>
		<view class="padding margin" v-if="emptyShow">
			<tn-empty 
			mode="data" 
			icon="https://tuniao.ahuaaa.cn/componentsPage/static/images/empty/data.jpg"
			imgWidth="300"
			></tn-empty>
		</view>
		<view class="padding-sm flex flex-wrap justify-between">
			<job-item  v-for="item in jobList" :jobdata="item"/>
		</view>
	</view>
</template>

<script>
import { jobGet } from '../../api/job'
	export default {
		data() {
			return {
				jobList:[],
				page:1,
				cateName:'',
				emptyShow:false
			}
		},
		onShow() {
			setTimeout(()=>{
				uni.getStorage({
					key:'cateName',
					// success: ({data}) => {
					// 	console.log('提取',{data});
					// 	this.jobList = []
					// 	this.page = 1
					// 	this.cateName = data
					// 	this.fetchData(data)
					// },
					// fail: (err) => {
					// 	this.jobList = []
					// 	this.page = 1
					// 	this.cateName = ''
					// 	this.fetchData()
					// },
					complete: ({data}) => {
						console.log('complete',data);
						this.jobList = []
						this.page = 1
						this.cateName = data
						this.fetchData(data)
					}
				})
			},200) //定时器为了保证onTabItemTap先执行
		},
		onReachBottom() {
			console.log('触底了');
			this.fetchData(this.cateName)
		},
		onPullDownRefresh() {
			this.jobList = []
			this.page = 1
			this.fetchData()
		},
		onTabItemTap() {
			console.log('点击了岗位菜单');
			uni.removeStorage({
				key:'cateName'
			})
		},
		methods:{
			fetchData(name){
				jobGet(this.page,name).then(res=>{
					uni.stopPullDownRefresh() //关闭下拉刷新动画
					let {results} = res.data
					if(this.page==1&&!results.length){
						this.emptyShow = true
					}
					if(results.length){
						this.emptyShow = false
						this.jobList = [
							...this.jobList,
							...results
						]
						this.page++
						return
					}
					uni.showToast({
						title:"没有更多数据了",
						icon:'none'
					})
				})
			}
		}
	}
</script>

<style>

</style>
