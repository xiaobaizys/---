<template>
  <view>
    <view class="flex justify-between padding align-center">
      <view class="">
        当前位置:{{ city }}
        <view class="text-xl"> 你好: {{ username }}! </view>
      </view>
      <text class="iconfont icon-a-001_tongzhi text-xxl text-gray"></text>
    </view>
    <view class="padding-lr">
      <custom-input />
      <!-- <custom-input icon="icon-a-1"/> -->
    </view>
    <swiper :indicator-dots="true">
      <swiper-item>
        <view class="swiper-item">
          <image src="../../static/img/1.png" mode="aspectFill"></image>
        </view>
      </swiper-item>
      <swiper-item>
        <view class="swiper-item">
          <image src="../../static/img/2.png" mode="aspectFill"></image>
        </view>
      </swiper-item>
      <swiper-item>
        <view class="swiper-item">
          <image src="../../static/img/3.png" mode="aspectFill"></image>
        </view>
      </swiper-item>
      <swiper-item>
        <view class="swiper-item">
          <image src="../../static/img/4.png" mode="aspectFill"></image>
        </view>
      </swiper-item>
    </swiper>

    <view class="cu-list grid col-4 no-border">
      <view class="cu-item" v-for="item in cateList" :key="item.objectId" @click="handleJobList(item)">
        <view class="text-center">
          <image class="grid-icon" :src="item.icon" mode="heightFix"></image>
          <text>{{ item.name }}</text>
        </view>
      </view>
      <view class="cu-item">
        <view class="text-center">
          <image class="grid-icon" src="../../static/img/home_grid5.png" mode="heightFix"></image>
          <text>更多</text>
        </view>
      </view>
    </view>
    <view class="flex justify-between padding">
      <text>为你推荐</text>
      <text class="text-sm text-orange des">查看更多</text>
    </view>
    <scroll-view scroll-x>
      <view class="padding-sm flex justify-between">
        <job-item v-for="item in jobList" :jobdata="item" class="margin-right-sm" />
      </view>
    </scroll-view>
    <view class="flex justify-between padding">
      <text>最新岗位</text>
      <text class="text-sm text-orange des">查看更多</text>
    </view>
    <view class="padding-sm">
      <job-item c-type="new" v-for="item in jobList" :jobdata="item" />
    </view>
  </view>
</template>

<script>
import { categoryGet, jobGet } from '../../api/job.js'
import { $get } from '../../utils/http.js'
export default {
  data() {
    return {
      cateList: [],
      jobList: [],
    }
  },
  computed: {
    city() {
      return this.$store.state.loc.city
    },
    username() {
      let { userInfo } = this.$store.state.user
      let name = userInfo ? userInfo.username : '游客访问'
      return name
    },
  },
  onLoad() {
    // 方法1:
    // uni.request({
    // 	url:'https://wojhrvmp.lc-cn-n1-shared.com/1.1/classes/category',
    // 	method:'GET',
    // 	header:{
    // 		"X-LC-Id": "WojHRvmpUDdDfo2kr9mfUVc2-gzGzoHsz",
    // 		"X-LC-Key": "RIiXkMSxvm1XzeptOeTOgvik",
    // 		"Content-Type": "application/json"
    // 	},
    // 	data:{
    // 		where:{
    // 			parentId:'0-0'
    // 		}
    // 	},
    // 	success: (res) => {
    // 		this.cateList = res.data.results
    // 	}
    // })
    //方法2：
    // $get('classes/category',{where:{parentId:'0-0'}}).then(res=>{
    // 	this.cateList = res.data.results
    // })
    // 方法3:
    categoryGet().then((res) => {
      this.cateList = res.data.results
    })

    jobGet().then((res) => {
      this.jobList = res.data.results
    })
  },
  methods: {
    handleJobList({ name }) {
      console.log('存入', name)
      uni.setStorage({
        key: 'cateName',
        data: name,
      })
      uni.switchTab({
        url: '/pages/company/company',
      })
    },
  },
}
</script>

<style lang="scss">
swiper {
  margin: 30upx;
}
.swiper-item {
  image {
    height: 320upx;
  }
}
.grid-icon {
  height: 64upx;
}
.text-xl {
  line-height: 30px;
}
.des {
  color: #008c8c;
}
</style>
