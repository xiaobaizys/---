<template>
	<view>
	  <view class="list" v-for="item in list">
	    <image :src="item.src"/>
	    <text class="title">{{item.title}}</text>
	    <text class="des">{{item.des}}</text>
	    <text class="titleRight">{{item.titleRight}}</text>
	    <text class="txt">{{item.txt>99?'99+':item.txt}}</text>
	  </view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				lists: [{
					src:'123'
				}],
				list: [
				      {
				        src: '../../static/img/avatar1.png',
				        title: '企业招聘',
				        titleRight: '今天',
				        des:'C企业招聘企业招聘企业招聘',
				        txt: 3
				      }, {
				        src: 'https://ts1.cn.mm.bing.net/th/id/R-C.8f98b80d4cd76834bc88c0ed2e9ad7bf?rik=OhoLf56XrTLD%2fQ&riu=http%3a%2f%2fis4.mzstatic.com%2fimage%2fthumb%2fPurple5%2fv4%2ff6%2fe4%2f81%2ff6e481e0-50d4-46f2-278c-cecd6d69d488%2fmzl.mstaioca.png%2f0x0ss-85.jpg&ehk=EP7MHAKY7DUbGoY1TWXVzVQVGv%2f1wp%2f%2fMB22tDTYjzQ%3d&risl=&pid=ImgRaw&r=0',
				        title: '直播招聘',
				        titleRight: '昨天',
				        des:'直播',
				        txt: 19
				      },
				      {
				        src: 'https://bpic.588ku.com/element_origin_min_pic/19/04/25/96ba60fa960090caa70da842cb2c89f5.jpg',
				        title: '通知',
				        titleRight: '星期一',
				        des:'通知企业招聘信息',
				        txt: 99
				      }, {
				        src: 'https://ts1.cn.mm.bing.net/th/id/R-C.67c70ed0eae200d69455a91b43a9f407?rik=JuGKKn2ExyU9PA&riu=http%3a%2f%2fwww.sucaijishi.com%2fuploadfile%2f2018%2f0508%2f20180508023717621.png&ehk=KU69IZrBC4o1Y88Iab8ZKx9FGLndJcignKsCkX31gds%3d&risl=&pid=ImgRaw&r=0&sres=1&sresct=1',
				        title: 'hr招聘',
				        titleRight: '星期二',
				        des:'简历',
				        txt: 19
				      },
				      {
				        src: 'https://img-qn.51miz.com/Element/00/77/28/91/87b3354b_E772891_4cf83b0b.png',
				        title: '张三',
				        titleRight: '星期三',
				        des:'哈哈哈',
				        txt: 99
				      },
					  {
					    src: '../../static/img/avatar2.png',
					    title: '王五',
					    titleRight: '星期一',
					    des:'通知企业招聘信息',
					    txt: 99
					  }, 
					  {
					    src: '../../static/img/avatar3.png',
					    title: '李四',
					    titleRight: '星期三',
					    des:'哈哈哈',
					    txt: 99
					  },
				     {
				       src: '../../static/img/avatar3.png',
				       title: '李四',
				       titleRight: '星期三',
				       des:'哈哈哈',
				       txt: 99
				     },
				
				    ]
			}
		},
		computed: {
			
		},
		methods: {
			
		
			
		}
	}
</script>

<style lang="scss">
.list{
  width: 100%;
  height: 65px;
  position: relative;
  border-bottom: 1px solid  rgb(240, 236, 236);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin: 10px 0;
}


.list image{
  width: 50px;
  height: 50px;
  vertical-align: text-top;
  border-radius: 10px;
  margin: 5px;
}
.list .title{
  display: inline-block;
  vertical-align: middle;
  margin-left: 10px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.list .des{
  width: 250px;
  display: inline-block;
  font-size: 13px;
  color: rgb(194, 183, 183);
  margin-left: 10px;
  position: absolute;
  left: 55px;
  bottom: 13px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.list .titleRight{
  float: right;
  margin-right: 10px;
  color: rgb(194, 183, 183);
  font-size: 12px;
}
.list .txt{
  display: inline-block;
  width: 20px;
  height: 20px;
  background-color: red;
  color: white;
  border-radius: 50%;
  font-size: 12px;
  position: absolute;
  left: 42px;
  text-align: center;
}

</style>
