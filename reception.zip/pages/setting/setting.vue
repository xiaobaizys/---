<template>
	<view>
		<view class="padding text-center">
			<image class="cu-avatar xl round" src="../../static/img/avatar2.png" mode=""></image>
			<view class="margin-top-sm">
				<button class="cu-btn line-orange" @click="handleUpload">修改头像</button>
			</view>
		</view>
		<view class="padding">
			<view class="margin-bottom-sm">
				姓名
			</view>
			<custom-input v-model="info.name" placeholder="请输入姓名" icon="icon-wode1"/>
		</view>
		<view class="padding">
			<view class="margin-bottom-sm">
				手机号
			</view>
			<custom-input v-model="info.phone" placeholder="请输入手机号" icon="icon-youxiang"/>
		</view>
		<view class="padding">
			<view class="margin-bottom-sm">
				简历
			</view>
			<view v-if="step!==0" class="cu-progress radius striped active">
				<view class="bg-orange" :style="[{ width:step+'%'}]">{{step}}%</view>
			</view>
			<button class="cu-btn line-orange block lg" @click="handleUpload">上传简历</button>
		</view>
		
		<view class="flex padding justify-between save-cont">
			<button class="cu-btn lg">取消</button>
			<button class="cu-btn lg bg-orange" @click="handleSave">保存</button>
		</view>
	</view>
</template>

<script>
	import { async } from 'regenerator-runtime';
	import {pathToBase64} from '../../js_sdk/mmmm-image-tools/index.js'
	import CloudSDK from 'leancloud-storage'
import { userUpdate } from '../../api/user.js';
import { userInfo } from 'os';
	export default {
		data() {
			return {
				info:{
					name:'admins',
					phone:'15992236606',
					resume:'',
				},
				step:0
			}
		},
		computed: {
			userInfo() {
				return this.$store.state.user.userInfo 
			}
		},
		methods: {
			handleSave(){
				// console.log(this.info);
				let {objectId,sessionToken} = this.userInfo
				userUpdate(objectId,sessionToken,this.info).then(res=>{
					let userInfo = {...this.userInfo,...this.info}
					this.$store.commit('initInfoMut',userInfo) //状态机存储
					uni.setStorage({ //本地持久化存储
						key:'fxjy-userinfo-v3',
						data:userInfo
					})
					uni.navigateBack({delta:1})
				})
			},
			handleUpload(){
				uni.chooseFile({
					success: async(file) => {
						// console.log(file);
						this.step = 30
						let {tempFilePaths} = file
						let base64 = await pathToBase64(tempFilePaths[0]) //将本地资源转为base64
						// console.log(base64);
						this.step = 60
						let cloudFile = new CloudSDK.File('resume.pdf',{base64}) //构建资源
						this.step = 90
						let res = await cloudFile.save() //保存资源
						// console.log(res);
						this.step = 99
						let {url} = res.attributes
						this.info.resume = url
						setTimeout(()=>{
							this.step = 100
						},500)
					}
				})
			}
		}
	}
</script>

<style lang="scss">
.save-cont{
	.cu-btn{
		width: 45%;
		flex-shrink: 0;
	}
}
</style>
