<template>
	<view v-if="detail">
		<view class="text-center">
			<image class="cu-avatar round xl margin-tb" :src="detail.brandLogo" mode=""></image>
			<view class="text-lg">
				{{detail.jobName}}
			</view>
			<view class="text-orange margin-tb-sm">
				薪资待遇:{{detail.salaryDesc}}
			</view>
		</view>
		<view class="flex justify-around margin">
			<view class="">
				<image class="cu-avatar round margin-right-sm" src="../../static/img/job_icon1.png" mode=""></image>
				{{distance}}km
			</view>
			<view class="">
				<image class="cu-avatar round margin-right-sm" src="../../static/img/job_icon2.png" mode=""></image>
				{{detail.cityName}} · {{detail.areaDistrict}}
			</view>
		</view>
		<view class="flex justify-around margin-tb">
			<view class="">
				岗位详情
			</view>
			<view class="" @click="navigator">
				企业信息
			</view>
		</view>
		<view class="padding">
			<view class="margin-bottom-sm">
				经验要求
			</view>
			<view class="">
				<view class="cu-tag bg-cyan" v-for="(item,index) in detail.jobLabels" :key="index">
					{{item}}
				</view>
			</view>
		</view>
		<view class="padding">
			<view class="margin-bottom-sm">
				技能要求
			</view>
			<view class="">
				<view class="cu-tag bg-orange" v-for="(item,index) in detail.skills" :key="index">
					{{item}}
				</view>
			</view>
		</view>
		<view class="padding">
			<view class="margin-bottom-sm">
				福利待遇
			</view>
			<view class="">
				<view class="cu-tag bg-purple" v-for="(item,index) in detail.welfareList" :key="index">
					{{item}}
				</view>
			</view>
		</view>
		<!-- <image src="../../static/img/loc.png" mode=""></image> -->
		<view class="padding">
			<view class="margin-bottom-sm">
				公司位置
			</view>
			<map 
				class="gd-map" 
				:longitude="jobLocation[0]" 
				:latitude="jobLocation[1]"
				:markers="[{
					id:1,
					longitude:jobLocation[0],
					latitude:jobLocation[1],
					iconPath:'../../static/img/loc.png',
					width:50,
					height:50
				}]"
			></map>
		</view>
		<view class="padding cu-bar foot">
			<button v-if="state==0" @click="handleJoin" class="cu-btn bg-orange lg block">立即报名</button>
			<button v-if="state==1" class="cu-btn bg-grey lg block">等待审核</button>
			<button v-if="state==2" class="cu-btn bg-brown lg block">已读简历</button>
			<button v-if="state==3" class="cu-btn bg-cyan lg block">预约面试</button>
			<button v-if="state==4" class="cu-btn bg-red lg block">已经拒绝</button>
		</view>
	</view>
</template>

<script>
	import { jobDetailGet, joinPost, joinStateGet } from '../../api/job';
	import { getDistance } from '../../utils/tools';
	export default {
		data() {
			return {
				detail:null,
				distance:0,
				jobLocation:[],
				state:0
			}
		},
		computed: {
			lnglat() {
				return this.$store.state.loc.lnglat //用户位置 
			},
			userInfo(){
				return this.$store.state.user.userInfo
			}
		},
		onLoad(options) {
			// console.log(options);
			jobDetailGet(options.id).then(res=>{
				this.detail = res.data
				let {cityName,areaDistrict,city} = res.data
				let address = cityName + areaDistrict
				this.getDist(address,city) //计算距离
			})
			this.checkState(options.id) //获取报名状态
		},
		methods: {
			getDist(address,city){
				//计算岗位距离
				let url = `https://restapi.amap.com/v3/geocode/geo?key=e0119d3cbd6eb284068484cadeb50e07&address=${address}&city=${city}`
				uni.request({
					url,
					success: (res) => {
						let {location} = res.data.geocodes[0]
						location = location.split(',') //岗位经纬度
						this.jobLocation = location
						let n = getDistance(location[1],location[0],this.lnglat[1],this.lnglat[0])
						this.distance = n.toFixed(1)
					}
				})
			},
			handleJoin(){
				//未登录引导登录
				if(!this.userInfo){
					uni.navigateTo({
						url:'/pages/login/login'
					})
					return
				}
				let {name,phone,resume} = this.userInfo
				// console.log(this.userInfo);
				//信息不完善引导完善信息
				if(!name||!phone||!resume){
					uni.showModal({
						title: '个人信息不完善',
						content: '请先完善个人信息后再进行报名操作',
						confirmColor:'orange',
						success: function (res) {
							if (res.confirm) {
								uni.navigateTo({
									url:'/pages/setting/setting'
								})
							}
						}
					});
					return
				}
				//报名逻辑
				let userid = this.userInfo.objectId
				let jobid = this.detail.objectId
				let {brandLogo,jobName,salaryDistrict,areaDistrict,cityName} = this.detail
				joinPost({
					userid,jobid,brandLogo,jobName,
					salaryDistrict,areaDistrict,cityName,
					state:1
				}).then(res=>{
					this.state = 1
				})
			},
			checkState(jobid){
				joinStateGet(this.userInfo.userid,jobid).then(res=>{
					console.log('报名数据',res);
					let {results} = res.data
					if(results.length){
						this.state = results[0].state //用户端报名状态保持跟后端一致
					}
				})
			},
			navigator(){
				uni.navigateTo({
					url:'/pages/enterprise/enterprise'
				})
			}
		}
	}
</script>

<style lang="scss">
.cu-btn.lg{
	width: 100%;
}
.cu-tag{
	margin: 10rpx 10rpx 0 0;
}
.gd-map{
	width: 100%;
	height: 300rpx;
	padding-bottom: 100px;
	// border: 1px solid red;
}
</style>
