<template>
	<view class="conatainer">
		<view class="header">工商信息</view>
		<view v-for="item in list" class="list">
			<view>公司全称：{{item.name}}</view>
			<view>成立日期：{{item.tiem}}</view>
			<view>注册资本：{{item.capital}}</view>
			<view>法定代表人：{{item.mankind}}</view>
			<view>企业类型：{{item.type}}</view>
			<view>经营状态：{{item.state}}</view>
			<view>注册地址：{{item.adders}}</view>
			<view>统一社会信用代码：：{{item.credit}}</view>
			<view class="range">经营范围：{{item.range}}</view>
		</view>
		<view class="padding">
			<button class="cu-btn bg-green block" @click="onshow">退出</button>
		</view>
		
	</view>
</template>

<script>
	export default {
		data(){
			return{
				list:[
				{
					name:'广州市揶揄电子科技有限公司',
					tiem:'2006-08-09',
					capital:'10万人民币',
					mankind:'张三',
					type:'有限责任公司（自然人投资或控股）',
					state:'在营',
					adders:'广州市番禺区',
					credit:'914401017910352666',
					range:'智能机器系统技术服务;信息电子技术服务;电力电子技术服务;信息技术咨询服务;通信技术研究开发、技术服务;计算机技术开发、技术服务;网络技术的研究、开发;电子产品零售;通信设备零售;计算机零售;计算机零配件零售;计算机批发;计算机零配件批发;通讯设备及配套设备批发;软件批发;电子元器件批发;智能机器销售;计算机网络系统工程服务;互联网商品销售（许可审批类商品除外）;互联网商品零售（许可审批类商品除外）;'
				},
				]
			}
		},
		methods:{
			onshow(){
				uni.switchTab({
					url: '/pages/company/company'
				});
			}
		}
	}
	
</script>

<style lang="scss">
	.conatainer{
		padding: 10px;
	}
	.header{
		font-size: 25px;
	}
	.list view{
		padding: 5px 0;
		font-size: 16px;
	}
	.range{
		line-height: 30px;
	}
</style>
