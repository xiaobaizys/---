<template>
	<view @click="handleDetail" class="job-item padding-sm margin-bottom-sm" :class="cType">
		<view class="flex justify-between align-center">
			<view class="flex align-center">
				<image class="cu-avatar round  margin-right-sm" :src="jobdata.brandLogo" mode=""></image>
				<!-- {{jobdata.brandName}} -->
			</view>
			<text class="iconfont icon-bookmark-o"></text>
		</view>
		<view class="margin-top-sm text-lg">
			{{jobdata.jobName}}
		</view>
		<view class="margin-tb-xs text-grey">
			{{jobdata.cityName}}·{{jobdata.areaDistrict}}
		</view>
		<view class="text-orange" v-if="cType=='hot'">
			{{jobdata.salaryDesc}}
		</view>
		<view v-if="cType=='new'" >
			<view class="cu-tag margin-bottom-xs margin-right-xs" v-for="item in jobdata.welfareList">
				{{item}}
			</view>
		</view>
		<view class="flex margin-top">
			<view class="margin-right">
				<text class="iconfont icon-browse margin-right-xs"></text>
				1000
			</view>
			<view class="">
				<text class="iconfont icon-renqun margin-right-xs"></text>
				500
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name:"job-item",
		props: {
			cType: {
				type: String,
				default: 'hot', //hot热门 new 最新  
				validator(value){
					return ['hot','new'].includes(value)
				}
			},
			jobdata:Object
		},
		data() {
			return {
				
			};
		},
		methods: {
			handleDetail() {
				uni.navigateTo({
					url:`/pages/detail/detail?id=${this.jobdata.objectId}`
				})
			}
		},
	}
</script>

<style lang="scss">
.job-item{
	border: 1px solid #EEEEEE;
	border-radius: 6upx;
	flex-shrink: 0;
}
.hot{
	width: 344upx;
}
.cu-tag{
	margin-left: 0;
}
.cu-avatar{
	height: 40upx;
	width: 40upx;
}
</style>